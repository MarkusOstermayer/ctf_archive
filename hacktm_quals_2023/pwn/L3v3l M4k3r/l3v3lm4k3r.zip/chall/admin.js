const puppeteer = require("puppeteer");
const path = require("path");
const fs = require('fs');


let queue = [];
const addToQueue = (exploit) => queue.push(exploit);

const TIMEOUT = process.env.TIMEOUT ? parseInt(process.env.TIMEOUT) : 30000;
const DELAY = process.env.DELAY ? parseInt(process.env.DELAY) : 500;

const visit = (exploit) => {
    let browser, page;
    return new Promise(async (resolve, reject) => {
        try {
            browser = await puppeteer.launch({
                headless: true,
                args: [
                    '--no-sandbox',
                    '--disable-gpu',
                    '--disable-setuid-sandbox',
                ],
                dumpio: true,
                executablePath: process.env.PUPPETEER_EXEC_PATH
            });
            page = await browser.newPage();

            await page.setCookie({
                'name': 'flag',
                'value': exploit.cookie,
                'domain': 'localhost:8080',
                'httpOnly': true
            });
            await page.goto(exploit.url, {
                waitUntil: "networkidle2"
            });
            //await page.waitForNavigation();
            const element = await page.$('input[type=file]');
            await element.uploadFile(exploit.file);
            //await element.evaluate(upload => upload.dispatchEvent(new Event('change', { bubbles: true })));

            await page.waitForTimeout(TIMEOUT);
            await page.close();
            await browser.close();
            page = null;
            browser = null;
        } catch (err) {
            console.log(err);
        } finally {
            if (page) await page.close();
            if (browser) await browser.close();
            resolve();
        }
    });
};

const loop = async () => {
    while (true) {
        let exploit = queue.shift();
        if (exploit) {
            console.log("vistiting:", exploit, queue);
            await visit(exploit);
            console.log("done visiting:", exploit, queue);
            //fs.unlinkSync(exploit.file);
        }
        await new Promise((resolve, reject) => setTimeout(resolve, DELAY));
    }
};

loop();
module.exports = {
    addToQueue, queue
};