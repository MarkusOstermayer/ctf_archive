const express = require("express");
const fileupload = require("express-fileupload");
const cookieParser = require("cookie-parser");
const admin = require("./admin.js");
const fetch = require('node-fetch')
const rateLimit = require('express-rate-limit')

const app = express();

require("dotenv").config();
const PORT = process.env.PORT || 8081;
const FLAG = process.env.FLAG || "HackTM{TEST_FLAG}";
const reCAPTCHAKEY = process.env.reCAPTCHA_KEY;

const rateLimiter = rateLimit({
	windowMs: 11* 30 * 1000, // 330 seconds
	max: 1
})
app.set('trust proxy', 1)

app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

app.use(fileupload({
    limits: { fileSize: 27048 },
    useTempFiles: true,
    tempFileDir: '/tmp/',
    safeFileNames: true
}));

app.use((req, res, next) => {
    // nginx sets this
    // checks whether request is coming from localhost :>
    req.isAdmin = req.cookies.flag === FLAG;
    res.setHeader("Cross-Origin-Opener-Policy", `same-origin`);
    res.setHeader("Cross-Origin-Embedder-Policy", `require-corp`);

    next();
});
app.use(express.static('public'));

app.get('/', function (req, res) {
    res.sendFile(__dirname + 'public/index.html');
});

app.get("/flag", (req, res) => {
    if (req.isAdmin)
        res.send(FLAG)
    else
        res.status(401).send('Unauthorized');
})

app.post("/visit", rateLimiter, async (req, res) => {
    if (!req.files || !req.files.exploit) {
        res.status(400).send("No file supplied");
        return;
    }

    if (req.files.exploit.size != 27048) {
        res.status(400).send("Incorrect file size.");
        return;
    }

    if (reCAPTCHAKEY) {
        if (!req.body || !req.body['g-recaptcha-response']) {
            res.status(400).send("No file reCAPTCHA");
            return;
        }

        try {
            let verifyURL = "https://www.google.com/recaptcha/api/siteverify?secret=" + reCAPTCHAKEY + "&response=" + encodeURIComponent(req.body['g-recaptcha-response']);
            // Hitting GET request to the URL, Google will respond with success or error scenario.
            let response = await fetch(verifyURL);
            if (!response.ok) {
                res.status(400).send("Something went wrong / incorrect recaptcha");
                return;
            }
            let body = await response.json();

            if (body.success !== undefined && !body.success) {
                res.status(400).send("Something went wrong / incorrect recaptcha");
                return;
            }

        }
        catch (ex) {
            res.status(400).send("Something went wrong. ");
            return;

        }
    }

    let filePath = req.files.exploit.tempFilePath;

    admin.addToQueue({
        "file": filePath,
        "url": `http://localhost:${PORT}/`,
        "cookie": FLAG
    });

    res.send("Success, position in queue: " + admin.queue.length)
});

app.get('/ip', (request, response) => response.send(request.ip))

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});