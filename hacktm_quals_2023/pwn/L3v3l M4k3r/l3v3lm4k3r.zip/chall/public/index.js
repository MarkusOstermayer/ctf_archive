
let canvas = document.getElementById("game");
let ctx = canvas.getContext('2d');

let ctxObject = {};
let memory = new WebAssembly.Memory({
    initial: 10,
    maximum: 100,
    shared: true,
});
for (let key of Object.keys(Object.getPrototypeOf(ctx))) {
    if (ctx[key] instanceof Function) {
        ctxObject[key] = ctx[key].bind(ctx);
    }
}

ctxObject["setFillColor"] = (e) => ctx.fillStyle = `#${e.toString(16)}`;

let importObject = {
    env: { memory },
    functions: {
        "consoleLog": console.log,
        "requestAnimationFrame": (e) => requestAnimationFrame(module.instance.exports.__indirect_function_table.get(e)),
        "spawnThread": (ptr, len) => {
            let bytes = new Uint8Array(memory.buffer, ptr, len);
            for (let i = 0; i < len; i++) {
                // len is incorrect?
                if (bytes[i] == 0) {
                    bytes = new Uint8Array(memory.buffer, ptr, i);
                    break;
                }
            }
            //const text = new TextDecoder("utf-8").decode(bytes);
            const text = String.fromCharCode.apply(null, bytes);
            // Verify url
            let worker = new Worker(text);
            window.thread = worker;
            worker.postMessage({
                "type": "memory",
                "memory": memory,
            })

        },
        "drawHealth": (ptr, len) => {
            const bytes = new Uint8Array(memory.buffer, ptr, len);
            // SharedArrayBuffers are not supported for TextDecoders
            //const text = new TextDecoder("utf-8").decode(bytes);
            const text = String.fromCharCode.apply(null, bytes);
            let healthIndicator = document.getElementById("health");
            healthIndicator.innerText = "Health: " + text;
        }
    },
    ctx: ctxObject,
    math: Math
}

let module = await WebAssembly.instantiateStreaming(fetch('main.wasm'), importObject);
window.module = module;
window.importObject = importObject;

module.instance.exports.start();

document.getElementById("levelUpload").addEventListener('change', (e) => {
    let reader = new FileReader();
    reader.addEventListener("load", (s) => {

        let arrayBuffer = s.target.result;
        if (arrayBuffer.byteLength != 27048)
            return;
        let array = new Uint8Array(arrayBuffer);

        let data = module.instance.exports.malloc(array.length);
        let buffer = new Uint8Array(memory.buffer);
        for (let i = 0; i < array.length; i++) {
            buffer[data + i] = array[i];
        }

        module.instance.exports.loadState(data);
        module.instance.exports.free(data);

    });
    reader.readAsArrayBuffer(e.target.files[0]);

}, false);

document.addEventListener("keydown", (e) => {
    module.instance.exports.onKeyDown(e.keyCode);
});

document.addEventListener("keyup", (e) => {
    module.instance.exports.onKeyUp(e.keyCode);
});

async function encryptFlag(flag) {
    let enc = new TextEncoder();
    let pt = enc.encode(flag);
    // no xor analysis
    let iv = new Uint8Array([81, 62, 98, 66, 69, 240, 205, 237, 65, 41, 101, 220, 140, 39, 27, 180])

    let key = await crypto.subtle.importKey(
        "raw",
        new Uint8Array([202, 102, 28, 101, 4, 34, 8, 203, 208, 209, 107, 44, 182, 218, 153, 203]),
        { name: "AES-CBC" },
        true,
        ["decrypt", "encrypt"]
    );

    let ciphertext = await window.crypto.subtle.encrypt(
        {
            name: "AES-CBC",
            iv
        },
        key,
        pt
    );
    return new Uint8Array(ciphertext);
}


document.getElementById("verifyFlag").addEventListener("click", async (e) => {
    let flag = document.getElementById("flag");
    if (flag.value.length != 256) {
        alert("Invalid flag length");
        return;
    }
    let ct = await encryptFlag(flag.value);

    let data = module.instance.exports.malloc(256);
    let buffer = new Uint8Array(memory.buffer);

    // Remove the last 32 bytes of padding
    for (let i = 0; i < 256; i++) {
        buffer[data + i] = ct[i];
    }

    let flagValid = module.instance.exports.checkFlag(data);
    module.instance.exports.free(data);

    if (flagValid) {
        flag.style.color = "green";
        alert("Correct flag");
    }
    else {
        flag.style.color = "red";
        alert("Wrong flag");
    }
})
