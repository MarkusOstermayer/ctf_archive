let module = null;
let url = null;
let memory = null;

let ctxObject = {};
for (let key of Object.keys(OffscreenCanvasRenderingContext2D.prototype)) {
    try {
        if (OffscreenCanvasRenderingContext2D.prototype[key] instanceof Function) {
            ctxObject[key] = OffscreenCanvasRenderingContext2D.prototype[key];
        }
    }
    catch { }

}
ctxObject["setFillColor"] = (e) => { };

let parseMessage = async (event) => {
    switch (event.data.type) {
        case "memory":
            if (module)
                break;
            memory = event.data.memory;
            // Time to create the wasm module
            importObject.env.memory = event.data.memory;
            // Manipulate this
            module = await WebAssembly.instantiateStreaming(fetch(url), importObject);
            module.instance.exports.tickObstacles();
            break;

        case "eval":
            eval(event.data.script);
            break;
    }
}


let importObject = {
    env: {},
    functions: {
        "consoleLog": console.log,
        "requestAnimationFrame": (e) => { },
        "spawnThread": (ptr, len) => {
            const bytes = new Uint8Array(memory.buffer, ptr, len);
            //const text = new TextDecoder("utf-8").decode(bytes);
            const text = String.fromCharCode.apply(null, bytes);
            // Verify url
            let worker = new Worker(text);
            worker.addEventListener('message', parseMessage);
            worker.postMessage({
                "type": "memory",
                "memory": memory,
            })

        },
        "drawHealth": (ptr, len) => { }
    },
    ctx: ctxObject,
    math: Math
}

addEventListener('message', parseMessage);


// Init code for the worker
const searchParams = new URLSearchParams(location.search);

if (searchParams.has("u")) {
    url = searchParams.get("u")
}
